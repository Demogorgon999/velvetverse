export type UserIntent =
  | 'Greeting'
  | 'Gratitude'
  | 'Identity'
  | 'Lore'
  | 'Knowledge'
  | 'Memory'
  | 'Secrets'
  | 'Fears'
  | 'Motivations'
  | 'Affection'
  | 'Comfort'
  | 'Question'
  | 'Unknown'

function containsAny(
  text: string,
  phrases: string[],
) {
  return phrases.some((phrase) =>
    text.includes(phrase),
  )
}

export function detectIntent(
  message: string,
): UserIntent {
  const lower = message.toLowerCase().trim()

  if (
    containsAny(lower, [
      'hello',
      'hi',
      'hey',
      'greetings',
      'good morning',
      'good afternoon',
      'good evening',
    ])
  ) {
    return 'Greeting'
  }

  if (
    containsAny(lower, [
      'thank you',
      'thanks',
      'appreciate',
    ])
  ) {
    return 'Gratitude'
  }

  if (
    containsAny(lower, [
      'how old are you',
      'what is your age',
      "what's your age",
      'how long have you been alive',
      'who are you',
      'who are you really',
      'what are you',
      'what species are you',
      'are you human',
      'where are you from',
      'where do you come from',
      'what is your homeland',
      "what's your homeland",
      'what do you do',
      'what is your role',
      "what's your role",
      'what is your occupation',
      "what's your occupation",
    ])
  ) {
    return 'Identity'
  }

  if (
    containsAny(lower, [
      'tell me about your past',
      'tell me your story',
      'tell me about your history',
      'what happened to you',
      'your story',
      'your history',
    ])
  ) {
    return 'Lore'
  }

  if (
    containsAny(lower, [
      'what do you know',
      'what can you teach me',
      'teach me',
      'what are you knowledgeable about',
    ])
  ) {
    return 'Knowledge'
  }

  if (
    containsAny(lower, [
      'what are you afraid of',
      'what do you fear',
      'what scares you',
      'what is your greatest fear',
    ])
  ) {
    return 'Fears'
  }

  if (
    containsAny(lower, [
      'what do you want',
      'what are your goals',
      'what is your goal',
      "what's your goal",
      'what is your purpose',
      'what motivates you',
    ])
  ) {
    return 'Motivations'
  }

  if (
    containsAny(lower, [
      'remember my name',
      'what is my name',
      "what's my name",
      'do you remember my name',
    ])
  ) {
    return 'Memory'
  }

  if (
    containsAny(lower, [
      'tell me a secret',
      'share a secret',
      'do you have any secrets',
      'what are you hiding',
      'secret',
    ])
  ) {
    return 'Secrets'
  }

  if (
    containsAny(lower, [
      'i love you',
      'i missed you',
      'i care about you',
      'you look beautiful',
      'you look handsome',
      'you look good',
      'you are beautiful',
      'you are handsome',
    ])
  ) {
    return 'Affection'
  }

  if (
    containsAny(lower, [
      'i am sad',
      "i'm sad",
      'i need help',
      'i feel lonely',
      'i am lonely',
      "i'm lonely",
      'i had a bad day',
      'i had a terrible day',
    ])
  ) {
    return 'Comfort'
  }

  if (lower.includes('?')) {
    return 'Question'
  }

  return 'Unknown'
}