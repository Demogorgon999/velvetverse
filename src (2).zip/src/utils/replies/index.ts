import type {
  CharacterEngineContext,
} from '../characterEngine'
import type {
  CharacterReply,
} from '../../types/reply'
import type {
  ReplyHandler,
  ReplyHandlerArgs,
} from './types'

import { detectIntent } from '../intent'
import {
  makeCharacterDecision,
} from '../decisionEngine'
import {
  detectCharacterEmotion,
} from '../emotionEngine'
import {
  createResponsePlan,
} from '../responsePlanner'

import {
  getGreetingReply,
} from './greetingReplies'
import {
  getGratitudeReply,
} from './gratitudeReplies'
import {
  getSecretReply,
} from './secretReplies'
import {
  getIdentityReply,
} from './identityReplies'
import {
  getLoreReply,
} from './loreReplies'
import {
  getMemoryReply,
} from './memoryReplies'
import {
  getFallbackReply,
} from './fallbackReplies'

import {
  generateDialogue,
} from '../../services/characterDialogueService'
import {
  createReply,
} from './replyFactory'

const replyHandlers: ReplyHandler[] = [
  getGreetingReply,
  getGratitudeReply,
  getSecretReply,
  getIdentityReply,
  getLoreReply,
  getMemoryReply,
]

export async function getCharacterReply(
  context: CharacterEngineContext,
  characterName: string,
  userMessage: string,
): Promise<CharacterReply> {
  const intent =
    detectIntent(userMessage)

  const decision =
    makeCharacterDecision({
      context,
      intent,
    })

  const detectedEmotion =
    detectCharacterEmotion({
      userMessage,
      mood: context.mood,
      relationshipStage:
        context.relationshipStage,
    })

  const responsePlan =
    createResponsePlan({
      context,
      intent,
      decision,
      emotion: detectedEmotion,
    })

  const args: ReplyHandlerArgs = {
    context,
    characterName,
    userMessage,
    lowerMessage:
      userMessage.toLowerCase(),
    intent,
    decision,
    emotion: detectedEmotion,
    responsePlan,
  }

  for (const handler of replyHandlers) {
    const reply = handler(args)

    if (reply) {
      return reply
    }
  }

  try {
    const dialogue =
      await generateDialogue(args)

    return createReply(
      dialogue.text,
      {
        emotion:
          detectedEmotion.emotion,
        animation:
          detectedEmotion.animation,
        internalThought:
          responsePlan.internalThought,
      },
    )
  } catch (error) {
    console.warn(
      'Dynamic dialogue unavailable. Using fallback reply.',
      error,
    )

    const fallbackReply =
      getFallbackReply(args)

    if (!fallbackReply) {
      throw new Error(
        'The fallback reply handler did not return a reply.',
      )
    }

    return fallbackReply
  }
}