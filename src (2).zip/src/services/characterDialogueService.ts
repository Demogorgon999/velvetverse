import type {
  ReplyHandlerArgs,
} from '../utils/replies/types'
import {
  buildCharacterPrompt,
} from './promptBuilder'

export type DialogueRequest = {
  characterName: string
  userMessage: string
  relationshipStage: string
  mood: string
  emotion: string
  decision: string
  disclosureLevel: string
  personalityInstructions: string[]
  relationshipInstruction: string
  moodInstruction: string
  relevantKnowledge: string[]
  relevantLore: string[]
  relevantSecrets: string[]
  relevantFears: string[]
  relevantGoals: string[]
  internalThought: string
}

export type DialogueResponse = {
  text: string
}

function createDialogueRequest(
  args: ReplyHandlerArgs,
): DialogueRequest {
  const {
    context,
    characterName,
    userMessage,
    decision,
    emotion,
    responsePlan,
  } = args

  return {
    characterName,
    userMessage,
    relationshipStage:
      context.relationshipStage,
    mood: context.mood.mood,
    emotion: emotion.emotion,
    decision: decision.decision,
    disclosureLevel:
      responsePlan.disclosureLevel,
    personalityInstructions:
      responsePlan.personalityInstructions,
    relationshipInstruction:
      responsePlan.relationshipInstruction,
    moodInstruction:
      responsePlan.moodInstruction,
    relevantKnowledge:
      responsePlan.relevantKnowledge,
    relevantLore:
      responsePlan.relevantLore,
    relevantSecrets:
      responsePlan.relevantSecrets,
    relevantFears:
      responsePlan.relevantFears,
    relevantGoals:
      responsePlan.relevantGoals,
    internalThought:
      responsePlan.internalThought,
  }
}

export async function generateDialogue(
  args: ReplyHandlerArgs,
): Promise<DialogueResponse> {
 const requestBody = {
  ...createDialogueRequest(args),
  prompt: buildCharacterPrompt(args),
}

  const response = await fetch(
    '/api/dialogue',
    {
      method: 'POST',
      headers: {
        'Content-Type':
          'application/json',
      },
      body: JSON.stringify(requestBody),
    },
  )

  if (!response.ok) {
    throw new Error(
      `Dialogue request failed with status ${response.status}.`,
    )
  }

  const data: unknown =
    await response.json()

  if (
    typeof data !== 'object' ||
    data === null ||
    !('text' in data) ||
    typeof data.text !== 'string' ||
    !data.text.trim()
  ) {
    throw new Error(
      'Dialogue service returned an invalid response.',
    )
  }

  return {
    text: data.text.trim(),
  }
}