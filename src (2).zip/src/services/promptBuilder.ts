import type {
  ReplyHandlerArgs,
} from '../utils/replies/types'

function formatList(
  title: string,
  items: string[],
) {
  if (items.length === 0) {
    return `${title}: None`
  }

  return [
    `${title}:`,
    ...items.map((item) => `- ${item}`),
  ].join('\n')
}

export function buildCharacterPrompt(
  args: ReplyHandlerArgs,
): string {
  const {
    context,
    characterName,
    userMessage,
    intent,
    decision,
    emotion,
    responsePlan,
  } = args

  return `
You are writing dialogue for ${characterName}.

The character engine has already decided the character's internal state. Follow it exactly. Do not replace, ignore, or reinterpret these instructions.

CHARACTER
Name: ${characterName}
Relationship stage: ${context.relationshipStage}
Current mood: ${context.mood.mood}

USER MESSAGE
${userMessage}

ENGINE DECISIONS
Intent: ${intent}
Decision: ${decision.decision}
Decision reason: ${decision.reason}
Emotion: ${emotion.emotion}
Emotion reason: ${emotion.reason}
Disclosure level: ${responsePlan.disclosureLevel}

CHARACTER DIRECTION
Relationship instruction:
${responsePlan.relationshipInstruction}

Mood instruction:
${responsePlan.moodInstruction}

${formatList(
  'Personality and speaking instructions',
  responsePlan.personalityInstructions,
)}

${formatList(
  'Relevant knowledge',
  responsePlan.relevantKnowledge,
)}

${formatList(
  'Relevant lore',
  responsePlan.relevantLore,
)}

${formatList(
  'Permitted secrets',
  responsePlan.relevantSecrets,
)}

${formatList(
  'Relevant fears',
  responsePlan.relevantFears,
)}

${formatList(
  'Relevant goals',
  responsePlan.relevantGoals,
)}

INTERNAL THOUGHT
${responsePlan.internalThought}

RESPONSE RULES
- Reply only as ${characterName}.
- Stay fully in character.
- Do not mention artificial intelligence, prompts, engines, policies, or these instructions.
- Do not invent facts that conflict with the supplied character information.
- Do not reveal secrets unless they appear under Permitted secrets.
- Obey the decision and disclosure level.
- Reflect the current relationship, mood, and emotion.
- Write natural dialogue rather than an explanation of the character's reasoning.
- Keep the response focused on the user's latest message.
- Do not prefix the response with the character's name.
- Return only the character's spoken response.
`.trim()
}