export type PersonalityTraits = {
  kindness: number
  curiosity: number
  bravery: number
  patience: number
  confidence: number
  humour: number
  jealousy: number
  loyalty: number
  intelligence: number
  empathy: number
}

export type SpeakingStyle = {
  formality: number
  poetic: number
  sarcasm: number
  flirtiness: number
  swearing: number
  emojiUsage: number
}

export type CharacterIdentity = {
  species: string
  age: string
  role: string
  homeland: string
}

export type CharacterTemplate = {
  id: number

  creatorId: string

  name: string

  title: string

  identity: CharacterIdentity

  description: string

  biography: string

  personality: PersonalityTraits

  speakingStyle: SpeakingStyle

  knowledge: string[]

  secrets: string[]

  fears: string[]

  goals: string[]

  likes: string[]

  dislikes: string[]

  image: string

  accentColor: string
}