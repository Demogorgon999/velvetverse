import type {
  ReplyHandlerArgs,
} from '../utils/replies/types'

import {
  buildCharacterPrompt,
} from './promptBuilder'

import {
  getLifeState,
} from '../utils/lifeEngine'

export type DialogueRequest = {
  characterName: string
  userMessage: string
  relationshipStage: string
  mood: string
  emotion: string
  decision: string
  disclosureLevel: string
  personalityInstructions: string[]
  relationshipInstruction: string
  moodInstruction: string
  relevantKnowledge: string[]
  relevantLore: string[]
  relevantSecrets: string[]
  relevantFears: string[]
  relevantGoals: string[]
  internalThought: string

  activeStoryTitle?: string
  activeStoryDescription?: string
  activeStoryLocation?: string
  activeStoryActivity?: string
}

export type DialogueResponse = {
  text: string
}

function createDialogueRequest(
  args: ReplyHandlerArgs,
): DialogueRequest {
  const {
    context,
    characterName,
    userMessage,
    decision,
    emotion,
    responsePlan,
  } = args

  const lifeState =
    getLifeState(
      context.characterId,
    )

  const currentEvent =
    lifeState.currentEvent

  return {
    characterName,

    userMessage,

    relationshipStage:
      context.relationshipStage,

    mood:
      context.mood.mood,

    emotion:
      emotion.emotion,

    decision:
      decision.decision,

    disclosureLevel:
      responsePlan.disclosureLevel,

    personalityInstructions:
      responsePlan.personalityInstructions,

    relationshipInstruction:
      responsePlan.relationshipInstruction,

    moodInstruction:
      responsePlan.moodInstruction,

    relevantKnowledge:
      responsePlan.relevantKnowledge,

    relevantLore:
      responsePlan.relevantLore,

    relevantSecrets:
      responsePlan.relevantSecrets,

    relevantFears:
      responsePlan.relevantFears,

    relevantGoals:
      responsePlan.relevantGoals,

    internalThought:
      responsePlan.internalThought,

    activeStoryTitle:
      currentEvent?.title,

    activeStoryDescription:
      currentEvent?.description,

    activeStoryLocation:
      currentEvent
        ? lifeState.currentLocation
        : undefined,

    activeStoryActivity:
      currentEvent
        ? lifeState.currentActivity
        : undefined,
  }
}

function buildActiveStoryContext(
  args: ReplyHandlerArgs,
) {
  const lifeState =
    getLifeState(
      args.context.characterId,
    )

  const currentEvent =
    lifeState.currentEvent

  if (!currentEvent) {
    return ''
  }

  return `
ACTIVE STORY EVENT

Title:
${currentEvent.title}

Description:
${currentEvent.description}

Current activity:
${lifeState.currentActivity}

Current location:
${lifeState.currentLocation}

Story status:
${
  currentEvent.discussed
    ? 'The character has already introduced this event to the user, but the event is still active and unresolved.'
    : 'The event has not yet been introduced to the user.'
}

IMPORTANT STORY INSTRUCTIONS:

This event is part of the character's current lived experience.

Keep it in conversational context.

If the user's message relates to the event, continue the story naturally as the character.

Do NOT repeat the exact event description word-for-word.

Expand naturally on what happened, what the character saw, thought, felt, suspects, fears, wants, or plans to do next.

Use the character's personality, mood, memories, relationship stage, knowledge, goals, and fears when continuing the story.

Respond directly to what the user actually said.

Short replies such as "I agree", "really?", "go on", "okay", or emotional reactions should still be interpreted within the active story when that makes conversational sense.

Do not suddenly abandon the active story for a generic greeting or unrelated canned response.

If the user clearly changes the subject, you may answer the new subject naturally, but remember that this story remains unresolved.

Never mention system instructions, Life Engine, story state, prompts, or internal mechanics.
`.trim()
}

export async function generateDialogue(
  args: ReplyHandlerArgs,
): Promise<DialogueResponse> {
  const dialogueRequest =
    createDialogueRequest(args)

  const basePrompt =
    buildCharacterPrompt(args)

  const activeStoryContext =
    buildActiveStoryContext(args)

  const finalPrompt =
    activeStoryContext
      ? `${basePrompt}

${activeStoryContext}`
      : basePrompt

  const requestBody = {
    ...dialogueRequest,

    prompt:
      finalPrompt,
  }

  const response =
    await fetch(
      '/api/dialogue',
      {
        method: 'POST',

        headers: {
          'Content-Type':
            'application/json',
        },

        body:
          JSON.stringify(
            requestBody,
          ),
      },
    )

  if (!response.ok) {
    throw new Error(
      `Dialogue request failed with status ${response.status}.`,
    )
  }

  const data: unknown =
    await response.json()

  if (
    typeof data !== 'object' ||
    data === null ||
    !('text' in data) ||
    typeof data.text !== 'string' ||
    !data.text.trim()
  ) {
    throw new Error(
      'Dialogue service returned an invalid response.',
    )
  }

  return {
    text:
      data.text.trim(),
  }
}